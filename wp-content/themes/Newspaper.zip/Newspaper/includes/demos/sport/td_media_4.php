<?php
/**
 * Created by ra on 6/13/2015.
 */



td_demo_media::add_image_to_media_gallery('td_pic_13',                  "http://demo_content.tagdiv.com/Newspaper_6/sport/13.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_14',                  "http://demo_content.tagdiv.com/Newspaper_6/sport/14.jpg");

td_demo_media::add_image_to_media_gallery('td_bg',                      "http://demo_content.tagdiv.com/Newspaper_6/sport/bg.jpg");

//post images
td_demo_media::add_image_to_media_gallery('td_pic_p1',                  "http://demo_content.tagdiv.com/Newspaper_6/sport/p1.jpg");
