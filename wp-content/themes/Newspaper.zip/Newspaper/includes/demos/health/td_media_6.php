<?php
//ads
td_demo_media::add_image_to_media_gallery('td_health_post_ad',              "http://demo_content.tagdiv.com/Newspaper_6/health/banner-post.jpg");
td_demo_media::add_image_to_media_gallery('td_health_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/health/banner-sidebar.jpg");
