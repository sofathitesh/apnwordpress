<?php
//ads
td_demo_media::add_image_to_media_gallery('td_travel_post_ad',              "http://demo_content.tagdiv.com/Newspaper_6/travel/rec-post.jpg");
td_demo_media::add_image_to_media_gallery('td_travel_smart6_ad',             "http://demo_content.tagdiv.com/Newspaper_6/travel/rec-smart.jpg");
td_demo_media::add_image_to_media_gallery('td_footer_bg',             "http://demo_content.tagdiv.com/Newspaper_6/travel/footer-bg.png");