<?php

td_demo_media::add_image_to_media_gallery('td_pic_s1',                  "http://demo_content.tagdiv.com/Newspaper_6/animals/s1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_s2',                  "http://demo_content.tagdiv.com/Newspaper_6/animals/s2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_s3',                  "http://demo_content.tagdiv.com/Newspaper_6/animals/s3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_s4',                  "http://demo_content.tagdiv.com/Newspaper_6/animals/s4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_s5',                  "http://demo_content.tagdiv.com/Newspaper_6/animals/s5.jpg");